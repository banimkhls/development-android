package ro.ovidiuconeaac.businesslayer.beans;

import ro.ovidiuconeac.models.Sweet;

/**
 * Created by ovidiu on 2/7/17.
 */

public interface SweetsBean {
    Sweet getRandomSweet();
}
