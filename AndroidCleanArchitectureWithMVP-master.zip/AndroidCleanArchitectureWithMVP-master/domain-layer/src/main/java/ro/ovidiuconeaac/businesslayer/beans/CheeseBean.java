package ro.ovidiuconeaac.businesslayer.beans;

import ro.ovidiuconeac.models.Cheese;

/**
 * Created by ovidiu on 2/7/17.
 */

public interface CheeseBean {
    Cheese getRandomCheese();
}
