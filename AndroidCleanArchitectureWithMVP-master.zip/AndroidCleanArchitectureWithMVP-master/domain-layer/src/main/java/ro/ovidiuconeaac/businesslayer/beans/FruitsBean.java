package ro.ovidiuconeaac.businesslayer.beans;

import ro.ovidiuconeac.models.Fruit;

/**
 * Created by ovidiu on 2/7/17.
 */

public interface FruitsBean {
    Fruit getRandomFruit();
}
