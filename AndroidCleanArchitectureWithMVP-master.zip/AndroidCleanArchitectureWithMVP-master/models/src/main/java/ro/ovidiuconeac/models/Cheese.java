package ro.ovidiuconeac.models;

/**
 * Created by ovidiu on 2/7/17.
 */

public class Cheese extends Food {

    public Cheese(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
